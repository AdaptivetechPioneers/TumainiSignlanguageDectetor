package com.example.boxes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
