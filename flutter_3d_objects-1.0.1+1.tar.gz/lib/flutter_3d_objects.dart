library flutter_3d_objects;

export 'src/widget.dart';
export 'src/scene.dart';
export 'src/object.dart';
export 'src/camera.dart';
export 'src/mesh.dart';
export 'src/material.dart';
export 'package:vector_math/vector_math_64.dart';
// /// A Calculator.
// class Calculator {
//   /// Returns [value] plus 1.
//   int addOne(int value) => value + 1;
// }
